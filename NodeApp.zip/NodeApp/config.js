//var Request = require("request");

//Request.post({
  //  "headers": { "content-type": "application/x-www-form-urlencoded", 
    //"authorization": "Bearer cGFOaWxncm91cDpncm91cA==" },
    //"url": "http://18.136.215.200:50000/",
    //"authorization" : { "type" : "OAuth 2.0"}, 
    //"body": JSON.stringify({
      //  "username": "patilgroup",
      //  "password": "group",
      //  "grant_type" : "password"
    //})
//}, (error, response, body) => {
  //  if(error) {
    //    return console.dir(error);
    //}
    //console.dir(JSON.parse(body));
//});