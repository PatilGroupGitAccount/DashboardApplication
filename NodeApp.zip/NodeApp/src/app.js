const express = require('express');
//const hbs = require("hbs");
//const path = require("path");
const app = express();

//const weatherData = require('../utils/weatherData');

//const port = process.env.PORT || 50000

const http = require('http');


//http.get({'host': 'api.ipify.org', 'port': 5000, 'path': '/'}, function(resp){
  //  resp.on('data', function(ip){
    //    console.log("My public IP address is: "+ip);
    //});
//});
const port = 50000;


var request = require("request");

request.post({
    "headers": { "Content-type": "application/x-www-form-urlencoded"},
   // "authorization": "Bearer cGFOaWxncm91cDpncm91cA==" },
    "uri": "http://18.136.215.200:50000/token",
   // "authorization" : { "type" : "OAuth 2.0"}, 
   // "body": JSON.stringify({
        form:({
        "username": "patilgroup",
        "password": "group",
        "grant_type" : "password"
    }),
  }, (error, response, body) => {
    if(error) {
        return console.error(error);
    }
    var json = JSON.parse(body);
    console.log(JSON.parse(body));
 
});




request.get({
    uri:"http://18.136.215.200:50000/eventCases", 
    headers: {
      
      'authorization': "Bearer eyJhbGciOiJodHRwOi8vd3d3LnczLm9yZy8yMDAxLzA0L3htbGRzaWctbW9yZSNobWFjLXNoYTI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1lIjoicGF0aWxncm91cCIsImh0dHA6Ly9zY2hlbWFzLm1pY3Jvc29mdC5jb20vd3MvMjAwOC8wNi9pZGVudGl0eS9jbGFpbXMvcm9sZSI6WyJEYXRhYmFzZUVkaXRDb25uZWN0aW9ucyIsIkRhdGFiYXNlU3dpdGNoIiwiRGF0YWJhc2VNYW5hZ2VFeHRlcm5hbCIsIk1lYXN1cmVtZW50Q29uZmlndXJhdGlvblZpZXciLCJNZWFzdXJlbWVudENvbmZpZ3VyYXRpb25FZGl0IiwiTWVhc3VyZW1lbnRDb25maWd1cmF0aW9uU2V0QWxhcm1MZXZlbHMiLCJub3RVc2VkNyIsIm5vdFVzZWQ4IiwiR2xvYmFsU3lzdGVtU2V0dGluZ3NWaWV3IiwiR2xvYmFsU3lzdGVtU2V0dGluZ3NFZGl0IiwiR2xvYmFsT1BDU2V0dGluZ3MiLCJHbG9iYWxTeXN0ZW1Mb2dWaWV3IiwiR2xvYmFsTGljZW5zZUtleSIsIlZpZXdzV29ya3NwYWNlVmlldyIsIlZpZXdzV29ya3NwYWNlRWRpdCIsIlZpZXdzRGlhZ3JhbVZpZXciLCJWaWV3c0RpYWdyYW1FZGl0IiwiVmlld3NQcm90ZWN0aW9uVmlldyIsIm5vdFVzZWQxOSIsIkFsYXJtc1ZpZXciLCJBbGFybXNBY2tub3dsZWRnZSIsIlVzZXJzTWFuYWdlVXNlcnNBbmRSb2xlcyIsIk1haW50ZW5hbmNlVmlld1BsYW5zIiwiTWFpbnRlbmFuY2VFZGl0UGxhbnMiLCJNYWludGVuYW5jZVZpZXdBY3Rpb25zIiwiTWFpbnRlbmFuY2VFeGVjdXRlQWN0aW9ucyIsIkRhdGFNaW5lclZpZXciLCJEYXRhTWluZXJFZGl0IiwiTGlicmFyaWVzUGljdHVyZUxpYnJhcnlWaWV3IiwiTGlicmFyaWVzUGljdHVyZUxpYnJhcnlFZGl0IiwiTGlicmFyaWVzQmVhcmluZ0xpYnJhcnlWaWV3IiwiTGlicmFyaWVzQmVhcmluZ0xpYnJhcnlFZGl0IiwiTGlicmFyaWVzUmVwb3J0TGlicmFyeVZpZXciLCJMaWJyYXJpZXNSZXBvcnRMaWJyYXJ5RWRpdCIsIkxpYnJhcmllc1RhZ0xpYnJhcnlWaWV3IiwiTGlicmFyaWVzVGFnTGlicmFyeUVkaXQiLCJOb3Rlc1ZpZXciLCJOb3Rlc0VkaXQiLCJBdHRhY2htZW50c1ZpZXciLCJBdHRhY2htZW50c0VkaXQiLCJFdmVudENhc2VzVmlldyIsIkV2ZW50Q2FzZXNFZGl0IiwiUHJvY2Vzc092ZXJ2aWV3VmlldyIsIlByb2Nlc3NPdmVydmlld0VkaXQiLCJUYWdTZXR0IiwiVGFnVmlldyIsIk1hY2hpbmVQYXJ0VmlldyIsIk1hY2hpbmVQYXJ0RWRpdCIsIk9ubGluZVRlcG9zaXRyeVN1Ym1pdCIsIk9ubGluZVRlcG9zaXRyeVJlY2lldmUiLCJQb3J0YWJsZXNVcGxvYWREb3dubG9hZFJvdXRlIiwibm90VXNlZDUzIiwiUG9ydGFibGVzRWRpdENvZGVkTm90ZXMiLCJCYWxhbmNpbmdVc2VOb3RVc2UiLCJXZWJBY2Nlc3NTaG93IiwiTkdBcHBBY2Nlc3MiLCJSYWlsVHJhY2tNb25pdG9yaW5nVmlldyIsIlJhaWxUcmFja01vbml0b3JpbmdFZGl0Iiwibm90VXNlZDYxIiwibm90VXNlZDYyIiwibm90VXNlZDYzIl0sImh0dHA6Ly9zY2hlbWFzLnhtbHNvYXAub3JnL3dzLzIwMDUvMDUvaWRlbnRpdHkvY2xhaW1zL3NpZCI6IjNhNjhhOGNjLWQ4NjYtNDVmMy1iMjEzLTg0ZTQ1MjBlY2ZjMiIsImh0dHA6Ly9zY2hlbWFzLnhtbHNvYXAub3JnL3dzLzIwMDUvMDUvaWRlbnRpdHkvY2xhaW1zL2VtYWlsIjoia3VuYWwua3VtYXJAc2tmLmNvbSIsImh0dHA6Ly9zY2hlbWFzLm1pY3Jvc29mdC5jb20vd3MvMjAwOC8wNi9pZGVudGl0eS9jbGFpbXMvdXNlcmRhdGEiOiIiLCJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9sb2NhbGl0eSI6IiIsImh0dHA6Ly9zY2hlbWFzLnhtbHNvYXAub3JnL3dzLzIwMDUvMDUvaWRlbnRpdHkvY2xhaW1zL2V1bGFBY2NlcHRlZCI6IiIsIm5iZiI6MTU4ODY4MTYzMiwiZXhwIjoxNTg4NjgyODMyLCJpc3MiOiJodHRwczovL29ic2VydmVyLnNrZi5jb20vd3MiLCJhdWQiOiJodHRwczovL29ic2VydmVyLnNrZi5jb20vb2F1dGgyL3YxIn0.5WmzN-mVOLJB2RAdQpEVNPHWSpk690ieXRGc-8jROuY"
    }
  }, function(err, httpResponse, body) {
    if (err) {
      return console.error('post failed:', err);
    }

    console.log('Get successful!  Server responded with:', body);
  });

  // Verify Token
function verifyToken(req, res, next) {
  // Get auth header value
  const bearerHeader = req.headers['authorization'];
  // Check if bearer is undefined
  if(typeof bearerHeader !== 'undefined') {
    // Split at the space
    const bearer = bearerHeader.split(' ');
    // Get token from array
    const bearerToken = bearer[1];
    // Set the token
    req.token = bearerToken;
    // Next middleware
    next();
  } else {
    // Forbidden
    res.sendStatus(403);
  }

}
 // app.listen(5000);